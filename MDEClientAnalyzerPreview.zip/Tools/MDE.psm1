﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2021 v5.8.194
	 Created on:   	10/19/2021 3:50 PM
	 Created by:   	ksarens
	 Updated 10/26/2102
	 	fixing error in help information
	 	adding support for offline scenarios
	 Organization: 	
	 Filename:     	MDEHelper.psm1
	===========================================================================
	.DESCRIPTION
		Helper functions for MDE Support solutions
#>

function checkEPPVersion
{
	<#
.SYNOPSIS
	Supportability of Defender EPP components
.DESCRIPTION
    Returns if the provided version of a component (MoCAMP, Engine, Sigs) is lower than the version online and no longer supported
.PARAMETER component
    The component to verify, this can be: MoCAMP|Engine|Sigs
.PARAMETER version
    The version of the component
.PARAMETER xml
    XML document containing the online versions (only needed in offline scenarios). In offline scenarios, the XML document needs to be provided, NOT the path to the xml file
.EXAMPLE
	checkEPPVersion -component MoCAMP -version 4.18.2009.6
        The result of the above example is True as this version is older than N-2 and no longer supported
.NOTES
	If there is no internet connectivity, the method will return $null, in this case provide the XML parameter (see above)
.LINK
#>
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[ValidateSet('MoCAMP', 'Engine','Sigs')]
		[string]$component,
		[Parameter(Mandatory = $true, Position = 1)]
		[string]$version,
		[Parameter(Mandatory = $false)]
		[xml]$xml,
		[Parameter(Mandatory = $false)]
		[System.Object]$proxy
	)
	
	Begin
	{
		$catch=$false
		if ($null -eq $script:EPP_Versions)
		{
			try {
				if($null -eq $xml)
				{
					$proxyuri = $proxyUri = $ProxyAddress.Address.AbsoluteUri
					if ($proxyuri) {
						$Response = Invoke-WebRequest -URI "https://www.microsoft.com/security/encyclopedia/adlpackages.aspx?action=info" -UseBasicParsing -Proxy $proxyuri
						[xml]$xml = $Response.Content
					} else {
						$Response = Invoke-WebRequest -URI "https://www.microsoft.com/security/encyclopedia/adlpackages.aspx?action=info" -UseBasicParsing
						[xml]$xml = $Response.Content
					}
				}
			}
			catch {
				$catch=$true
			}
			
			
			$script:EPP_Versions = New-Object System.Management.Automation.PSObject
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "MoCAMP" -NotePropertyValue $xml.ChildNodes[1].platform
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "Engine" -NotePropertyValue $xml.ChildNodes[1].engine
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "Sigs" -NotePropertyValue $xml.ChildNodes[1].signatures.'#text'
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "Date" -NotePropertyValue $xml.ChildNodes[1].signatures.date
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "Updated" -NotePropertyValue (Get-Date -Format "MM/dd/yyyy HH:mm")
		}
		if ($version -like "*-*")
		{
			$version = $version.split('-')[0]
		}
	}
	Process
	{
		if($catch)
		{return $null}
		Try
		{
			switch ($component)
			{
				"MoCAMP" {
					
					if ([System.version]$script:EPP_Versions.MoCAMP -gt [System.version]$version)
					{
						$online = @()
						$online += [int]$script:EPP_Versions.MoCAMP.split('.')[0]
						$online += [int]$script:EPP_Versions.MoCAMP.split('.')[1]
						$online += [int]$script:EPP_Versions.MoCAMP.split('.')[2]
						$online += [int]$script:EPP_Versions.MoCAMP.split('.')[3]
						
						$current = @()
						$current += [int]$version.split('.')[0]
						$current += [int]$version.split('.')[1]
						$current += [int]$version.split('.')[2]
						$current += [int]$version.split('.')[3]
						if (($online[2] - $current[2]) -ge 3 -or (($online[2] - $current[2]) -gt 90 -and ($online[2] - $current[2]) -lt 92))
						{
							return $true
						}
						return $false
					}
				}
				"Sigs" {
					if ([System.version]$script:EPP_Versions.Sigs -gt [System.version]$version)
					{
						return $true
					}
				}
				"Engine" {
					if ([System.version]$script:EPP_Versions.Engine -gt [System.version]$version)
					{
						return $true
					}
				}
			}
			return $false
		}
		Catch
		{
			#Write-Log -Message "ERROR $($MyInvocation.MyCommand) [$($var)] - [$_]" -Severity 3
		}
		
	}
	End
	{
		[GC]::Collect()
	}
}
Export-ModuleMember checkEPPVersion
# SIG # Begin signature block
# MIIn4AYJKoZIhvcNAQcCoIIn0TCCJ80CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBR7crhJ6bHuRx4
# gRKDHBCcKnfh7JIAxH/tJo119OGBI6CCDZcwggYVMIID/aADAgECAhMzAAADz7d0
# vUQxddCTAAAAAAPPMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjQwMjIyMTkwNzUzWhcNMjUwMjE5MTkwNzUzWjCBlDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjE+MDwGA1UEAxM1TWlj
# cm9zb2Z0IFdpbmRvd3MgRGVmZW5kZXIgQWR2YW5jZWQgVGhyZWF0IFByb3RlY3Rp
# b24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDwAPmxMmR9a92NX/Lv
# 2PmaySDZqZUANxu28n+GqAuhMRrC8/v5HrKeebKt+6wqnp28fO1jvJ5OlBIrirN7
# KUiSUH86mvByCFnIwIkKcusZbgEF+v15S0jRExa5C9lC+kDVYtlSCnPEdx/tkKLN
# QQMmSroC3baj7y0WIvBfZ1l4x2qyDhFC/5plmMfD8TSfl3sN4twBiXAcpJ/SES50
# QbLahl/MTsVA2UEo7ygPJIrmci8wvD0Kt1pfkwbB3eiK4Vatr0VoJujRucjGT322
# m/9vH6p4Y5suUJMo9196/ze8hA8bqH+5NdU+DeRLrV/UzVat1Xs/Wm6kPK8GgTPL
# H+M9AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBggrBgEFBQcDAwYKKwYBBAGCN0wv
# ATAdBgNVHQ4EFgQU10vjUl0bvgJvpCFtGT8ECb23+CAwRQYDVR0RBD4wPKQ6MDgx
# HjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEWMBQGA1UEBRMNNDUxODk0
# KzUwMjA2OTAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8E
# TTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9N
# aWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBR
# BggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0
# cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAw
# DQYJKoZIhvcNAQELBQADggIBAHcmfqgz/boPmZhEOAtYI5wj3mRicbSQwDQcGZfK
# 8I1WdILE80dhNGqgtVvxO5v5/PyjBJY5HV9HxxCzdVVj60PYAwzoyfTIZF+0hPrh
# l6JkjfckCiy9qsONVkL6SDJH6a+Xf4penA2ge9WM3XLR5BUQH538wx4w+VswV1QX
# hKsAMGAvxBG8EzIFTMRXMoKy/RYZ1FSig96mdJRb9Zh4o37XcyAgSxlbiv50vu3X
# MGNXRZJY0/PdB6Du55mI0WfJDaKBJuDShBMLOjDRX8UEWjy3rqGTjVVLYhK4mWq6
# I/1bIZlgkKBFnUMFbVvtSWDP13FgyGIVDk5YB5s2XmSC6hTfXAHakSpLfFeZ1VK5
# /pRMdhxEenleDdsgksd9idt+U7YxgjZ6gfdGuWgj9ZNi8Ef4ILoA5fkUGIIP14a7
# j2SUsaYvJKw/5aiVHRza+Q9gbDpNcsR5WbhhcSAnkFmi7ZkmJKHVlkUqAUDbP8WB
# yz/bq6m/HCHELfFfsG4HMvOfLSTVhKfXPptRzN4N5m2AZX423KM2zhqzPjCWNWce
# /jqhUKtbyMuPPqqo+eaoYi+ZzaEqirxAmPF6Nz3VIncZppzm451L2Uu05NwN1T5m
# ZbiGW2WW1Iz50ofUKACCqThHMtSh4fOdq0OiKaqQz3S5BGdoXdPPOKgXxOtfaMpr
# C3SrMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWlj
# cm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4
# MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3Y
# bqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUB
# FDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnbo
# MlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT
# +OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuy
# e4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEh
# NSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2
# z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3
# s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78Ic
# V9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E
# 11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5P
# M4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcV
# AQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3
# FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAf
# BgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBL
# hklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNS
# b29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggr
# BgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNS
# b29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsG
# AQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwA
# ZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0G
# CSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDB
# ZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc
# 8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYq
# wooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu
# 5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWI
# UUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXh
# j38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yH
# PgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtI
# EJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4Guzq
# N5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgR
# MiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQ
# zTGCGZ8wghmbAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEC
# EzMAAAPPt3S9RDF10JMAAAAAA88wDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcN
# AQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUw
# LwYJKoZIhvcNAQkEMSIEIIa9twzD0gIEzNqHA4E0uYjlFiSzMpiszR14lRPdtFQd
# MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAEggEACSB+aIeLce11
# 4D/hyORLDBHxxdfnmTCqtcsxgCIG0JqrkkXz5XtOyiRo2Mw6I+Mii7ZkCLflPA9y
# c19lKHCeu/4B1e822g7cdXI01Kt8DTXcO3ZAGhECkrDwWF/89Ye9c3dmgYjogev/
# rPMGpX0KJhK7tqkw9OPhwTurJiA8PN77HL2TQQ6YTsp6CfZgYtkXhHB95mdO+0uR
# SUq+jHU4FCQJsxzFws8nbbeXtJZw+OeMkgCTifbi82FPF5HHKAY4X4n6ofibThVx
# xfEwZ6qXCx27mCQu/6Vrnsi1Su+PyqNkPIrZCY1qtY6imPJWEMWGCIyxUlCrsA17
# ZWe8y31QzaGCFykwghclBgorBgEEAYI3AwMBMYIXFTCCFxEGCSqGSIb3DQEHAqCC
# FwIwghb+AgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFZBgsqhkiG9w0BCRABBKCCAUgE
# ggFEMIIBQAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQCAQUABCCsZlK/Rh5t
# FaKepDmKluWRDMn3rF/2ce3h4kgENsKS2gIGZlPWpW3+GBMyMDI0MDUyOTE0MzYz
# NS43NTVaMASAAgH0oIHYpIHVMIHSMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25z
# IExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjJBRDQtNEI5Mi1GQTAx
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIReDCCBycw
# ggUPoAMCAQICEzMAAAHenkielp8oRD0AAQAAAd4wDQYJKoZIhvcNAQELBQAwfDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWlj
# cm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjMxMDEyMTkwNzEyWhcNMjUw
# MTEwMTkwNzEyWjCB0jELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVk
# MSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjoyQUQ0LTRCOTItRkEwMTElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBALSB9ByF9UIDhA6xFrOniw/xsDl8sSi9rOCOXSSO4VMQ
# jnNGAo5VHx0iijMEMH9LY2SUIBkVQS0Ml6kR+TagkUPbaEpwjhQ1mprhRgJT/jlS
# nic42VDAo0en4JI6xnXoAoWoKySY8/ROIKdpphgI7OJb4XHk1P3sX2pNZ32LDY1k
# tchK1/hWyPlblaXAHRu0E3ynvwrS8/bcorANO6DjuysyS9zUmr+w3H3AEvSgs2Re
# uLj2pkBcfW1UPCFudLd7IPZ2RC4odQcEPnY12jypYPnS6yZAs0pLpq0KRFUyB1x6
# x6OU73sudiHON16mE0l6LLT9OmGo0S94Bxg3N/3aE6fUbnVoemVc7FkFLum8KkZc
# bQ7cOHSAWGJxdCvo5OtUtRdSqf85FklCXIIkg4sm7nM9TktUVfO0kp6kx7mysgD0
# Qrxx6/5oaqnwOTWLNzK+BCi1G7nUD1pteuXvQp8fE1KpTjnG/1OJeehwKNNPjGt9
# 8V0BmogZTe3SxBkOeOQyLA++5Hyg/L68pe+DrZoZPXJaGU/iBiFmL+ul/Oi3d83z
# LAHlHQmH/VGNBfRwP+ixvqhyk/EebwuXVJY+rTyfbRfuh9n0AaMhhNxxg6tGKyZS
# 4EAEiDxrF9mAZEy8e8rf6dlKIX5d3aQLo9fDda1ZTOw+XAcAvj2/N3DLVGZlHnHl
# AgMBAAGjggFJMIIBRTAdBgNVHQ4EFgQUazAmbxseaapgdxzK8Os+naPQEsgwHwYD
# VR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYDVR0fBFgwVjBUoFKgUIZO
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWljcm9zb2Z0JTIw
# VGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwGCCsGAQUFBwEBBGAwXjBc
# BggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0
# cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcnQwDAYD
# VR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAOBgNVHQ8BAf8EBAMC
# B4AwDQYJKoZIhvcNAQELBQADggIBAOKUwHsXDacGOvUIgs5HDgPs0LZ1qyHS6C6w
# fKlLaD36tZfbWt1x+GMiazSuy+GsxiVHzkhMW+FqK8gruLQWN/sOCX+fGUgT9LT2
# 1cRIpcZj4/ZFIvwtkBcsCz1XEUsXYOSJUPitY7E8bbldmmhYZ29p+XQpIcsG/q+Y
# jkqBW9mw0ru1MfxMTQs9MTDiD28gAVGrPA3NykiSChvdqS7VX+/LcEz9Ubzto/w2
# 8WA8HOCHqBTbDRHmiP7MIj+SQmI9VIayYsIGRjvelmNa0OvbU9CJSz/NfMEgf2NH
# MZUYW8KqWEjIjPfHIKxWlNMYhuWfWRSHZCKyIANA0aJL4soHQtzzZ2MnNfjYY851
# wHYjGgwUj/hlLRgQO5S30Zx78GqBKfylp25aOWJ/qPhC+DXM2gXajIXbl+jpGcVA
# NwtFFujCJRdZbeH1R+Q41FjgBg4m3OTFDGot5DSuVkQgjku7pOVPtldE46QlDg/2
# WhPpTQxXH64sP1GfkAwUtt6rrZM/PCwRG6girYmnTRLLsicBhoYLh+EEFjVviXAG
# Tk6pnu8jx/4WPWu0jsz7yFzg82/FMqCk9wK3LvyLAyDHN+FxbHAxtgwad7oLQPM0
# WGERdB1umPCIiYsSf/j79EqHdoNwQYROVm+ZX10RX3n6bRmAnskeNhi0wnVaeVog
# LMdGD+nqMIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG
# 9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEy
# MDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIw
# MTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az
# /1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V2
# 9YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oa
# ezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkN
# yjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7K
# MtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRf
# NN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SU
# HDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoY
# WmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5
# C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8
# FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TAS
# BgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1
# Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUw
# UzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoG
# CCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIB
# hjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fO
# mhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9w
# a2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggr
# BgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNv
# bS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3
# DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEz
# tTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJW
# AAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G
# 82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/Aye
# ixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI9
# 5ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1j
# dEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZ
# KCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xB
# Zj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuP
# Ntq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvp
# e784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAtQw
# ggI9AgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBM
# aW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjoyQUQ0LTRCOTItRkEwMTEl
# MCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsO
# AwIaAxUAaKBSisy4y86pl8Xy22CJZExE2vOggYMwgYCkfjB8MQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOoBoNAwIhgPMjAyNDA1
# MjkyMDQwNDhaGA8yMDI0MDUzMDIwNDA0OFowdDA6BgorBgEEAYRZCgQBMSwwKjAK
# AgUA6gGg0AIBADAHAgEAAgIKDzAHAgEAAgIT1jAKAgUA6gLyUAIBADA2BgorBgEE
# AYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYag
# MA0GCSqGSIb3DQEBBQUAA4GBAD23CTR1HW5qP0zd52RmXZU0sPMJQddFJkhW5S0v
# 53I46VcCwjNRtdC0wfmpAyGGLIpCnWNOWICj79gKO9EJzlN9CdOKgd06bs9YKIuK
# fQm20A6YmXLDSM5datmmVJxXC+nPGNtQT16tWyy2IpR6p6ehH89diqq1tQaKcND6
# cWaTMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAC
# EzMAAAHenkielp8oRD0AAQAAAd4wDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3
# DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgYfDIbgbDibGxB03D
# d6VcYyAyK5fj0BjfU1QWc5nE4EQwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9
# BCCOPiOfDcFeEBBJAn/mC3MgrT5w/U2z81LYD44Hc34dezCBmDCBgKR+MHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB3p5InpafKEQ9AAEAAAHeMCIE
# IDJsPgHzGTt4hROiKGb0Gfi0IpTqfxwyuEoYcIooDTFfMA0GCSqGSIb3DQEBCwUA
# BIICAAv6mLOyvhlgZH+oU2nRXc62lvR1N+Y94ejIEKnYfj6bLgRZN2oHMAEfnY5K
# /XJARcd3qZPPb85LVQVL825RdsucH8y4Lmri325n72gGq6RPqPYFDYwHv9Gno0aH
# 5EqKmJLJhvBOcGCk3cNZYDnBuVI4s8GGaeppAtRC657McFjIaKeKDzMzjIi2kVBO
# X6fE1dERxfvCIYSweRtF3s9Q+BCibpw+j8NOIuBXSdZ6ht9WE1XHASpQKcJDd1Bf
# P/XvywMgQt+zz7ZJqa6DKRNyP0erBBtF/cmknEQda48Xrvz0hCF0slUXklxLuAWh
# vRO4ngq9z87FROWF2Fjz6TSz6szHBcA2pGMSMSkV5ochfh8KD0djAZxYnQ8ontV1
# SDHcTN6kRNRfqRfEwMUvUv/Ky/jyVXLkebhQX8wpqfVykbpL0N8DJzuPzMwf2xb0
# v5DQYtOoYTOIqCmo8OsMujAtDJobA18XUNpUT+EWL6t3Uy0IArXP163RiqaG1WsQ
# blssbfUCKbzM5jVlUvSqDMes/5msN/EpTqse4mXAiHoBJR1ZRheuSbQlShlw3Gq2
# VerR82KRgDvhjxfRPa5mbYiEjbWkNbcQ/grPzDhd5AQqcgmkhHQfJtR6163QN9qE
# 0ScNTioX0SvTlbW52lRZpcWuSl6sm4SLF+o3xuM5g8m5mVT4
# SIG # End signature block
